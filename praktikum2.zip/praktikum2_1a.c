#include <stdio.h>

int main() { 
    int tanggal = 17;
    int bulan = 8;
    printf("Tanggal %i, Bulan %d", tanggal, bulan);
    return 0;
}