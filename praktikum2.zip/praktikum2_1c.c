#include <stdio.h>

int main() { 
    int a, b;
    printf("Angka pertama: ");
    scanf("%d", &a);
    printf("Angka kedua: ");
    scanf("%i", &b);
    printf("\nNilai desimal dari angka pertama adalah: %i", a);
    printf("\nNilai oktal dari angka kedua adalah: %i", b);
    return 0;
}