#include <stdio.h>

int main() {
    char huruf = 'Y';
    
    printf("%c", huruf);

return 0;
}