#include <stdio.h>
typedef unsigned char BYTE;
int main()
{
    BYTE b1, b2;
    b1 = 'c';
    printf("%c ", b1);
    return 0;
}