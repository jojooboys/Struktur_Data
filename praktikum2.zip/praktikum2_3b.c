#include <stdio.h>

int main() {
    char kalimat[10] = "AnbiDev";
    printf("%s", kalimat);

return 0;
}